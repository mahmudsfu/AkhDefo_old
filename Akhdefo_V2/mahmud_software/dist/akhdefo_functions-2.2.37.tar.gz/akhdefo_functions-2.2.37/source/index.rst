.. akhdefo documentation master file, created by
   sphinx-quickstart on Thu Jan 12 23:09:40 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to akhdefo's documentation!
===================================

.. toctree::
	api  
	

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
