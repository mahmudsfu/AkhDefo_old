﻿akhdefo\_functions.Crop\_to\_AOI
================================

.. currentmodule:: akhdefo_functions

.. autofunction:: Crop_to_AOI