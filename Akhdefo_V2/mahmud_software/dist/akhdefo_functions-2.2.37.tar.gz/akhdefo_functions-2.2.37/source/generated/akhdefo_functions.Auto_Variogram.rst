﻿akhdefo\_functions.Auto\_Variogram
==================================

.. currentmodule:: akhdefo_functions

.. autofunction:: Auto_Variogram