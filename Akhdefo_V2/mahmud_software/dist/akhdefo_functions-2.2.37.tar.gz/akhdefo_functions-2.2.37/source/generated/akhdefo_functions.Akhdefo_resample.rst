﻿akhdefo\_functions.Akhdefo\_resample
====================================

.. currentmodule:: akhdefo_functions

.. autofunction:: Akhdefo_resample