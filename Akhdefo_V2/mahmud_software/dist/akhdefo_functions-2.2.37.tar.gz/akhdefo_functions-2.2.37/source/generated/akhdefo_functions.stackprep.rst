﻿akhdefo\_functions.stackprep
============================

.. currentmodule:: akhdefo_functions

.. autofunction:: stackprep