﻿akhdefo\_functions.MeanProducts\_plot\_ts
=========================================

.. currentmodule:: akhdefo_functions

.. autofunction:: MeanProducts_plot_ts