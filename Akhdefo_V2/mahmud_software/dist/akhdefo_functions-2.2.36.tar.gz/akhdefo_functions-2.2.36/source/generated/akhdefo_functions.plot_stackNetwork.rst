﻿akhdefo\_functions.plot\_stackNetwork
=====================================

.. currentmodule:: akhdefo_functions

.. autofunction:: plot_stackNetwork