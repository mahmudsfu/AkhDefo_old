﻿akhdefo\_functions.akhdefo\_viewer
==================================

.. currentmodule:: akhdefo_functions

.. autofunction:: akhdefo_viewer