﻿akhdefo\_functions.unzip
========================

.. currentmodule:: akhdefo_functions

.. autofunction:: unzip