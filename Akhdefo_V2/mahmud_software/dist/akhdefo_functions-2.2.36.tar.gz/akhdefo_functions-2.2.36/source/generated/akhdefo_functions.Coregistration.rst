﻿akhdefo\_functions.Coregistration
=================================

.. currentmodule:: akhdefo_functions

.. autofunction:: Coregistration