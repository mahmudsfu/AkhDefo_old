﻿akhdefo\_functions.Time\_Series
===============================

.. currentmodule:: akhdefo_functions

.. autofunction:: Time_Series