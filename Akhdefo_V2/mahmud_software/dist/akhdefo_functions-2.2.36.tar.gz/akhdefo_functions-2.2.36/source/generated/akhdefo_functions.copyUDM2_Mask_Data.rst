﻿akhdefo\_functions.copyUDM2\_Mask\_Data
=======================================

.. currentmodule:: akhdefo_functions

.. autofunction:: copyUDM2_Mask_Data