﻿akhdefo\_functions.Akhdefo\_inversion
=====================================

.. currentmodule:: akhdefo_functions

.. autofunction:: Akhdefo_inversion