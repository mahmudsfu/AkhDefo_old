﻿akhdefo\_functions.utm\_to\_latlon
==================================

.. currentmodule:: akhdefo_functions

.. autofunction:: utm_to_latlon