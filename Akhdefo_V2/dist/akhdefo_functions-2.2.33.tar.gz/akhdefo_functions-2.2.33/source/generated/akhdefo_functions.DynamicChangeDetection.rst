﻿akhdefo\_functions.DynamicChangeDetection
=========================================

.. currentmodule:: akhdefo_functions

.. autofunction:: DynamicChangeDetection