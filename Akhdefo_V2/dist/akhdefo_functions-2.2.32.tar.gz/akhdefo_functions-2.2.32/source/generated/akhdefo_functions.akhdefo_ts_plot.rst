﻿akhdefo\_functions.akhdefo\_ts\_plot
====================================

.. currentmodule:: akhdefo_functions

.. autofunction:: akhdefo_ts_plot