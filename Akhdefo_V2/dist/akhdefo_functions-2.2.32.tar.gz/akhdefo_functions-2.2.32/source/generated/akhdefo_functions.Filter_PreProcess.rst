﻿akhdefo\_functions.Filter\_PreProcess
=====================================

.. currentmodule:: akhdefo_functions

.. autofunction:: Filter_PreProcess